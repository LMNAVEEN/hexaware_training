package com.service;

import com.model.cartitem;
import com.exception.InvalidNameException;
import com.exception.InvalidPriceException;

import java.math.BigDecimal;
import java.util.List;

public class CartService {

    public void validateItems(List<cartitem> items) {
        if (items == null) throw new NullPointerException("Items cannot be null");

        for (cartitem item : items) {
            if (item.getName() == null || item.getName().isEmpty())
                throw new InvalidNameException("Invalid name");

            if (item.getPrice().compareTo(BigDecimal.ZERO) < 0)
                throw new InvalidPriceException("Invalid price");
        }
    }

    public BigDecimal calculateTotal(List<cartitem> items) {
        BigDecimal total = BigDecimal.ZERO;

        for (cartitem item : items) {
            total = total.add(item.getPrice()
                    .multiply(BigDecimal.valueOf(item.getQuantity())));
        }

        return total;
    }
}