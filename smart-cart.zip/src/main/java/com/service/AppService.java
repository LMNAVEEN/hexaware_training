package com.service;

import com.model.cartitem;
import com.model.user;

import java.math.BigDecimal;
import java.util.List;

public class AppService {

    private CartService cartService = new CartService();
    private UserService userService = new UserService();

    public BigDecimal computeTotalCost(List<cartitem> items, user user) {

        userService.validateUser(user);
        cartService.validateItems(items);

        BigDecimal total = cartService.calculateTotal(items);

        if (userService.isPremium(user) &&
                total.compareTo(new BigDecimal("500")) > 0) {
            total = total.subtract(total.multiply(new BigDecimal("0.10")));
        } else if (total.compareTo(new BigDecimal("1000")) > 0) {
            total = total.subtract(total.multiply(new BigDecimal("0.05")));
        }

        return total;
    }
}