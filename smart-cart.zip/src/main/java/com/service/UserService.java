package com.service;

import com.model.user;

public class UserService {

    public void validateUser(user user) {
        if (user == null)
            throw new NullPointerException("User cannot be null");

        if (user.getUsername() == null || user.getUsername().isEmpty())
            throw new RuntimeException("Invalid username");

        if (!user.getStatus().equals("NORMAL") &&
            !user.getStatus().equals("PREMIUM"))
            throw new RuntimeException("Invalid status");
    }

    public boolean isPremium(user user) {
        return user.getStatus().equals("PREMIUM");
    }
}