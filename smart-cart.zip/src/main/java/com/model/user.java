package com.model;

public class user {
    private int id;
    private String username;
    private String status;

    public user(int id, String username, String status) {
        this.id = id;
        this.username = username;
        this.status = status;
    }

    public String getUsername() { return username; }
    public String getStatus() { return status; }
}