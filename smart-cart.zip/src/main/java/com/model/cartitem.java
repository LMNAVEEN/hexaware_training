package com.model;

import java.math.BigDecimal;

public class cartitem {
    private int id;
    private String name;
    private BigDecimal price;
    private int quantity;

    public cartitem(int id, int quantity, BigDecimal price, String name) {
        this.id = id;
        this.quantity = quantity;
        this.price = price;
        this.name = name;
    }

    public String getName() { return name; }
    public BigDecimal getPrice() { return price; }
    public int getQuantity() { return quantity; }
}